ORBIT ACADEMY v5.5 - standalone edition
=======================================

An interactive course in orbital mechanics: 8 modules, each pairing a written
worksheet with a live 3-D simulator you fly yourself.


START HERE
----------

  1. Unzip this folder anywhere you like (Desktop is fine).
  2. Open the file  START-HERE.html  by double-clicking it.
  3. Pick Module 1 and work down the list.

That is the entire installation. Nothing to install, no account to make, and no
internet connection is needed - now or ever. Everything runs inside your browser
from the files in this folder.

Use Chrome, Edge or Firefox. Safari is stricter about pages opened directly from
disk and a few simulators misbehave there.


HOW THE COURSE WORKS
--------------------

Each module is a pair:

  - a WORKSHEET  - the reading, the exercises, and a short quiz. Answer a quiz
                   question correctly and that exercise is ticked off.
  - a SIMULATOR  - the thing you actually fly. Every worksheet exercise tells you
                   what to do in it and what to look for.

Keep both open side by side. Every simulator has a  [] Back to worksheet  button
at its top-left, and every worksheet has a button that opens its simulator.

The modules, in order:

   1. How orbits work            5. xGEO / cislunar space and reference frames
   2. Angular rates and geosync  6. Lagrange points and complex orbits
   3. Naming orbits and TLEs     7. Observability - how we see satellites
   4. Maneuvers and delta-v      8. Lunar transfers - the flight-sim capstone

Budget roughly 45-90 minutes per module if you do the exercises properly. There
is also a course-wide final quiz and a printable completion certificate.


DRIVING THE SIMULATORS
----------------------

  drag                rotate or pan the view
  scroll / pinch      zoom (hold Shift for fine control)
  arrow keys          rotate, hands-free
  , and .             slow down / speed up TIME. You will use these constantly:
                      a low orbit takes 90 minutes, a lunar trip takes days.
  R                   reset the view if you get lost

Every slider also has a box beside it - type an exact number and press Enter
when an exercise asks for a specific value.


YOUR PROGRESS
-------------

Ticked exercises are saved in the browser you used, on that computer. Use the
same browser to pick up where you left off. Progress does NOT follow you to
another machine, and clearing your browsing data will clear it.

Working through it more than once, or sharing a computer? Each browser profile
keeps its own separate progress.


TEACHING A GROUP?
-----------------

Download the FULL edition instead. Same course, plus: student accounts, progress
that follows each student between machines, modules that unlock in order, an
instructor roster showing exactly where the class struggled, and an editor for
the worksheets. It needs Node.js (one free installer) and starts by
double-clicking a launcher.


IF SOMETHING LOOKS WRONG
------------------------

A blank or frozen simulator is almost always a browser issue rather than a
broken file: try reloading the page, and try Chrome if you are not already using
it. CHANGELOG.md in this folder lists what changed in each version.
